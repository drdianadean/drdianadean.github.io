% Diana Siwiak
% 424 Final Project
% Hemi 6 Speaker Filter Design
%% Please make sure the following files are in the same folder as this one,
% as they are used!
%   cbsmoother.m
%   minPhase.m
%   erb2khz.m
%   khz2erb.m
%   sinesweep.wav
%   Speaker*3dB.wav

%%
% Let's define some wave files, our number of bins and number of taps
[s,fs] = wavread('sinesweep.wav');
r2 = wavread('Speaker23dB.wav');
r3 = wavread('Speaker33dB.wav');
r4 = wavread('Speaker43dB.wav');
r5 = wavread('Speaker53dB.wav');
r6 = wavread('Speaker63dB.wav');
nbins = 512;
ntaps = fs/2;

% We're going to use the second sine sweep, so here's where we reset the
% index in order to pull the proper sound clip for each speaker.
asamp = 2^20;
index = asamp + [1:asamp];
rr = r2(index);
ss = s(index);
ir2 = ifft(fft(rr)./fft(ss));
ir2 = ir2(1:ntaps)/max(abs(ir2));

rr = r3(index);
ir3 = ifft(fft(rr)./fft(ss));
ir3 = ir3(1:ntaps)/max(abs(ir3));

rr = r4(index);
ir4 = ifft(fft(rr)./fft(ss));
ir4 = ir4(1:ntaps)/max(abs(ir4));

rr = r5(index);
ir5 = ifft(fft(rr)./fft(ss));
ir5 = ir5(1:ntaps)/max(abs(ir5));

rr = r6(index);
ir6 = ifft(fft(rr)./fft(ss));
ir6 = ir6(1:ntaps)/max(abs(ir6));

% Here is our array to use all the drivers
irs = [ir2 ir3 ir4 ir5 ir6];

figure(gcf);
plot([0:fs/2-1]/fs,irs + 2*ones(ntaps,1)*[0:size(irs,2)-1]); grid;
title('Measured Impulse Responses');
pause;

figure(gcf);
plot([0:fs/2-1]/fs,db(abs(irs))); grid;
title('Measured Impulse Responses on dB scale');
pause;

% This is to matrix multiply an array of ones with the mean of the impulse
% response array
ir0 = ones(ntaps,1)*mean(irs(1:900,:));

figure(gcf);
plot([0:fs/2-1],(irs - ir0) + 2*ones(ntaps,1)*[0:size(irs,2)-1]); grid;
title('Mean Measured Impulse Responses');
pause;


figure(gcf);
plot([0:fs/2-1]/fs,db(abs(irs-ir0))); grid;
title('Mean Measured Impulse Responses on dB scale');
pause;

% This is how much of the impulse response we'll use, which is pretty much
% equivalent to the direct path
irds = irs(920+[1:nbins],:)-ones(nbins,1)*mean(irs(1:900,:));

figure(gcf);
plot([0:nbins-1]/fs,irds + 2*ones(nbins,1)*[0:size(irds,2)-1]); grid;
title('Range of Applicable Measured Impulse Responses');
pause;

% Here is where we build and define our window, a delayed raised cosine
coswin = 0.5*cos([1:nbins/2]/(nbins/2)*pi)+0.5;
b4cos = ones(nbins/2,1);
rcos = [b4cos; coswin'];

figure(gcf);
plot(rcos);
title('Our Delayed Raised Cosine Window');
pause;

% This is where we apply our delayed raised cosine window to our impulse
% responses
nir = size(irds,2);
irdsw = irds.*(rcos*ones(1,nir));

figure(gcf);
plot([0:nbins-1]/fs,irdsw + 2*ones(nbins,1)*[0:size(irdsw,2)-1]); grid;
title('Mean of Windowed Measured Impulse Responses');
pause;

figure(gcf);
plot([0:nbins-1]/fs,[irds irdsw] + [2*ones(nbins,1)*[0:size(irds,2)-1] 2*ones(nbins,1)*[0:size(irds,2)-1]]); grid;
title('Mean of Measured Impulse Responses against Windowed Measured Impulse Responses');
pause;

% Let's take the transfer function of our windowed impulse response
tfs = abs(fft(irdsw,2*nbins));

figure(gcf);
plot(db(tfs));
title('Windowed Transfer Functions on dB scale');
pause;

figure(gcf);
semilogx([0:nbins]/nbins*fs/2,db(tfs(1:nbins+1,:)));grid;ylim([-30 30]);xlim([20 30000]);
title('Windowed Transfer Functions on dB scale');
pause;

% Here we apply our critical band smoothing to our various impulse
% responses so we can start to build our correction filter
cb6=cbsmoother(ir6,3,44100);
tfd = abs(fft(irdsw,2*nbins));
tf6s = cbsmoother(tfd(:,5),3,44100);
irdsw(:,5);

figure(gcf);
semilogx([0:nbins]/nbins*fs/2,db([tfd(1:nbins+1,5) tf6s(1:nbins+1)]));grid;
title('Windowed Transfer Function vs. Smoothed Windowed Transfer Function for Speaker 6');
pause;

% Let's take the minimum phase of our transfer function to get our impulse
% response
ir6s = minPhase(real(ifft(tf6s)));

figure(gcf);
plot([ir6s(1:nbins) irdsw(:,5)]);grid;
title('Impulse Response vs. Smoothed Impulse Response for Speaker 6');
pause;

figure(gcf);
plot(abs(fft([ir6s(1:nbins) irdsw(:,5)],2*nbins)));grid;
title('Transfer Function vs. Smoothed Transfer Function for Speaker 6');
pause;

% Here we take in signals, normalize them and convolve them to re-create
% the sound of the slork speaker and our filter
signal = wavread('DrumLoop.wav');
signal = signal/max(abs(signal));

irsignal = fftfilt(irdsw(:,5),signal);
irsignal = signal/max(abs(irsignal));

irsmoothsignal = fftfilt(ir6s(1:nbins),signal);
irsmoothsignal = irsmoothsignal/max(abs(irsmoothsignal));

% Now we take the inverse of our windowed smoothed meaned transfer function
% for filter creation
tfinv = 1./(tf6s/max(tf6s)+0.01*((max(tf6s)-tf6s)./max(tf6s)-min(tf6s)).^2);
irinv = minPhase(real(ifft(tfinv)));

figure(gcf);
plot(db(abs(fft(irinv,2*nbins))));grid;
title('Our Inverse Smoothed Windowed Transfer Function for Filter Design');
pause;

% Some convolution
irinvsignal = fftfilt(irinv(1:nbins),signal);
irinvsignal = irinvsignal/max(abs(irinvsignal));

% And now we hear the result
hold on;
sound([signal/max(abs(signal)); irsignal; irinvsignal; signal/max(abs(signal))],44100);
hold off;
pause;

% This is for all of the drivers, you can tell how inconsistent they are,
% and how using the correction of one, doesn't relate to another
ssignal = fftfilt(irdsw, signal(:)*ones(1,size(irdsw,2)));

hold on;
sound(ssignal(:)/max(max(abs(ssignal))),44100);
hold off;
