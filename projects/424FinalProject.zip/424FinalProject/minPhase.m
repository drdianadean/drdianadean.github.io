% Diana Siwiak
% MUS 424
% Homework 4
% minimum phase script
% Group work with Chris Warren

function m = minPhase(ir)

H = fft(ir);                     % fourier transform of the impulse response
Hlog = log(abs(H));              % form the log magnitude transform
Hil = imag(hilbert(Hlog));       % you need only the imaginary part of the hilbert
m = real(ifft(exp(Hlog - j*Hil)));     % taken from the equation in the book on page 292