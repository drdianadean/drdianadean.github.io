How to Use:

Run hemiFilter.m in Matlab