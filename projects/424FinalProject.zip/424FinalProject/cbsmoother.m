% Diana Siwiak
% MUS 424

function tfs = cbsmoother(tf,B,fs)

N = length(tf);
tfs=zeros(N/2+1,1);

fsInkHz = fs/1000;
ourBins = [0:N-1]/N*fsInkHz;

for i = 1:N/2+1
    lowEdge = erb2khz(khz2erb(ourBins(i)) - B/2)/fsInkHz*N+1;
    highEdge = erb2khz(khz2erb(ourBins(i)) + B/2)/fsInkHz*N+1;
    tfs(i) = sqrt(mean(abs(tf(round(lowEdge:highEdge))).^2));
end
tfs = [tfs;flipud(tfs(2:N/2))];
