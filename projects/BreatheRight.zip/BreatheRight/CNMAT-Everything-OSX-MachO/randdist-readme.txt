randdist uses portions of the GNU Scientific Library (www.gnu.org/software/gsl/).
